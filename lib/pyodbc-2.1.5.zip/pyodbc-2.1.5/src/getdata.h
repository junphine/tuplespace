
#ifndef _GETDATA_H_
#define _GETDATA_H_

void GetData_init();

PyObject* GetData(Cursor* cur, Py_ssize_t iCol);

#endif // _GETDATA_H_
